function addVideo() {
    const fileInput = document.getElementById('video-input');
    const files = fileInput.files;

    if (files.length === 0) {
        alert('Por favor selecciona un video.');
        return;
    }

    const videoContainer = document.querySelector('.videos-container');

    Array.from(files).forEach(file => {
        const videoURL = URL.createObjectURL(file);

        const videoCard = document.createElement('div');
        videoCard.classList.add('video-card');

        videoCard.innerHTML = `
            <video controls>
                <source src="${videoURL}" type="video/mp4">
                Tu navegador no soporta videos HTML5.
            </video>
            <p>Nuevo video subido</p>
        `;

        videoContainer.appendChild(videoCard);
    });

    fileInput.value = '';
}
